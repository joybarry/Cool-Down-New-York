


document.addEventListener('DOMContentLoaded', function() {
    const image = document.getElementById('printable-image');

    image.addEventListener('click', function() {
        const printWindow = window.open('', '_blank');
        printWindow.document.write('<html><head><title>Print Image</title></head><body>');
        printWindow.document.write('<img src="' + image.src + '" style="width: 100%; height: auto;">');
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    });
});

document.addEventListener('DOMContentLoaded', (event) => {
    const readMoreButtons = document.querySelectorAll('.readMoreBtn');

    readMoreButtons.forEach(button => {
        button.addEventListener('click', function() {
            const contentBlock = this.closest('.content-block');
            const dots = contentBlock.querySelector('.dots');
            const moreText = contentBlock.querySelector('.more');

            if (dots.style.display === "none") {
                dots.style.display = "inline";
                this.innerHTML = "Read More";
                moreText.style.display = "none";
            } else {
                dots.style.display = "none";
                this.innerHTML = "Read Less";
                moreText.style.display = "block";
            }
        });
    });
});



